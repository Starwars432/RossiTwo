/// <reference types="vite/client" />

declare const __ENABLE_VISUAL_EDITOR__: boolean;