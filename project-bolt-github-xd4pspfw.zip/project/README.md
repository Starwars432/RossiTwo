# Rossi

[Edit in StackBlitz next generation editor ⚡️](https://stackblitz.com/~/github.com/Starwars432/Rossi)